const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const STYLE_PROMPTS: Record<string, string> = {
  minimal: "Minimalist style: clean lines, lots of negative space, simple geometric forms, monochrome or limited palette.",
  luxury: "Luxury style: elegant serif or refined typography, gold/black/cream palette, premium feel, refined detailing.",
  modern: "Modern style: bold geometric shapes, vibrant gradients, contemporary tech-forward aesthetic.",
  vintage: "Vintage style: retro typography, distressed textures, classic badge or emblem composition, warm muted tones.",
  playful: "Playful style: friendly rounded shapes, bright cheerful colors, approachable cartoonish character.",
  futuristic: "Futuristic style: neon glow, cyberpunk palette, sleek angular forms, sci-fi feel.",
  handdrawn: "Hand-drawn style: organic ink strokes, sketchy lines, artisan crafted feel.",
  corporate: "Corporate style: professional, balanced, blue/grey palette, trustworthy and clean.",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { prompt, referenceImage, mode, style, count = 1 } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    let baseInstruction = "";
    if (mode === "logo") {
      baseInstruction = "Generate a professional, clean, vector-style logo design suitable for a brand identity, on a clean background. Centered composition.";
    } else if (mode === "graphic") {
      baseInstruction = "Generate a high-quality, visually striking graphic design illustration with vibrant composition.";
    } else if (mode === "sketch") {
      baseInstruction = "Analyze the provided hand-drawn sketch carefully. Create a polished, professional, enhanced logo based on the sketch's core shapes, symbols and intent. Keep the original concept but elevate it into a clean, modern, vector-style logo with refined typography if applicable, on a clean background.";
    }

    const styleHint = style && STYLE_PROMPTS[style] ? `\nStyle: ${STYLE_PROMPTS[style]}` : "";
    const n = Math.max(1, Math.min(4, Number(count) || 1));

    const variantSeeds = [
      "Variation A: emphasize symmetry and iconic mark.",
      "Variation B: emphasize typography and wordmark.",
      "Variation C: combine icon + text in a creative layout.",
      "Variation D: alternative color palette and composition.",
    ];

    const callOnce = async (variantHint: string) => {
      const userContent: any[] = [{
        type: "text",
        text: `${baseInstruction}${styleHint}\n${variantHint}\n\nUser request: ${prompt || "(no additional prompt)"}`,
      }];
      if (referenceImage) {
        userContent.push({ type: "image_url", image_url: { url: referenceImage } });
      }

      const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash-image",
          messages: [{ role: "user", content: userContent }],
          modalities: ["image", "text"],
        }),
      });

      if (!response.ok) {
        const t = await response.text();
        console.error("Gateway error", response.status, t);
        const err: any = new Error("Generation failed");
        err.status = response.status;
        throw err;
      }
      const data = await response.json();
      return data.choices?.[0]?.message?.images?.[0]?.image_url?.url as string | undefined;
    };

    const results = await Promise.allSettled(
      Array.from({ length: n }, (_, i) => callOnce(variantSeeds[i] || ""))
    );

    const images = results
      .filter((r) => r.status === "fulfilled" && r.value)
      .map((r: any) => r.value as string);

    if (images.length === 0) {
      const firstErr = results.find((r) => r.status === "rejected") as any;
      const status = firstErr?.reason?.status;
      if (status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit reached. Try again shortly." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add credits in Lovable workspace." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      return new Response(JSON.stringify({ error: "No image returned" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ images, image: images[0] }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
