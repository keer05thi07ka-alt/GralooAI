import { useState } from "react";
import Landing from "@/components/Landing";
import Dashboard from "@/components/Dashboard";

const Index = () => {
  const [view, setView] = useState<"landing" | "dashboard">("landing");
  return view === "landing" ? (
    <Landing onLaunch={() => setView("dashboard")} />
  ) : (
    <Dashboard onHome={() => setView("landing")} />
  );
};

export default Index;
