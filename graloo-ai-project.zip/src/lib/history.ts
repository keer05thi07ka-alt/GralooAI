export type HistoryItem = {
  id: string;
  mode: "logo" | "graphic" | "sketch";
  prompt: string;
  style?: string;
  image: string;
  createdAt: number;
};

const KEY = "graloo_history_v1";
const MAX = 60;

export function getHistory(): HistoryItem[] {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
}

export function addToHistory(items: Omit<HistoryItem, "id" | "createdAt">[]) {
  const existing = getHistory();
  const newOnes: HistoryItem[] = items.map((it) => ({
    ...it,
    id: crypto.randomUUID(),
    createdAt: Date.now(),
  }));
  const merged = [...newOnes, ...existing].slice(0, MAX);
  localStorage.setItem(KEY, JSON.stringify(merged));
  window.dispatchEvent(new Event("graloo-history-updated"));
}

export function removeFromHistory(id: string) {
  const next = getHistory().filter((i) => i.id !== id);
  localStorage.setItem(KEY, JSON.stringify(next));
  window.dispatchEvent(new Event("graloo-history-updated"));
}

export function clearHistory() {
  localStorage.removeItem(KEY);
  window.dispatchEvent(new Event("graloo-history-updated"));
}

export const STYLE_OPTIONS = [
  { value: "minimal", label: "Minimal" },
  { value: "luxury", label: "Luxury" },
  { value: "modern", label: "Modern" },
  { value: "vintage", label: "Vintage" },
  { value: "playful", label: "Playful" },
  { value: "futuristic", label: "Futuristic" },
  { value: "handdrawn", label: "Hand-drawn" },
  { value: "corporate", label: "Corporate" },
];
