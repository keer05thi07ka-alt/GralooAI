import { Button } from "@/components/ui/button";
import { Sparkles, PenTool, ImageIcon, ArrowRight } from "lucide-react";

interface LandingProps {
  onLaunch: () => void;
}

const Landing = ({ onLaunch }: LandingProps) => {
  return (
    <main className="relative min-h-screen overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-50" />
      <div className="absolute inset-0 bg-gradient-glow" />

      <header className="relative z-10 mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-hero glow-primary">
            <Sparkles className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-lg font-semibold tracking-tight">GralooAI</span>
        </div>
        <Button variant="ghost" onClick={onLaunch} className="hidden sm:inline-flex">
          Open Studio <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </header>

      <section className="relative z-10 mx-auto flex max-w-5xl flex-col items-center px-6 pb-20 pt-16 text-center sm:pt-28">
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-4 py-1.5 text-xs font-medium text-muted-foreground backdrop-blur">
          <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
          AI-Powered Design Studio
        </div>

        <h1 className="text-5xl font-bold tracking-tight sm:text-7xl">
          <span className="text-gradient">GralooAI</span>
          <br />
          <span className="text-foreground">Design at the speed of thought.</span>
        </h1>

        <p className="mt-6 max-w-2xl text-lg text-muted-foreground">
          Generate stunning logos and graphics from a prompt, or sketch your idea and let our AI
          transform it into a polished brand-ready design.
        </p>

        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <Button size="lg" onClick={onLaunch} className="bg-gradient-hero text-primary-foreground hover:opacity-90 glow-primary">
            Start Creating <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
          <Button size="lg" variant="outline" onClick={onLaunch}>
            Explore Studio
          </Button>
        </div>

        <div className="mt-24 grid w-full gap-6 sm:grid-cols-3">
          {[
            { icon: Sparkles, title: "Logo Generator", desc: "Brand-ready logos from a single prompt." },
            { icon: ImageIcon, title: "Graphics Studio", desc: "Eye-catching graphics for any campaign." },
            { icon: PenTool, title: "Sketch to Logo", desc: "Draw it. AI refines it to perfection." },
          ].map((f) => (
            <div
              key={f.title}
              className="group rounded-2xl border border-border bg-gradient-surface p-6 text-left shadow-card backdrop-blur transition-smooth hover:border-primary/40"
            >
              <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary group-hover:bg-primary/20">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-semibold">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
};

export default Landing;
