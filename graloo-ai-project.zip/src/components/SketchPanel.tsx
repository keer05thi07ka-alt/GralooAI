import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Eraser, Wand2, Trash2, Download, Loader2, Upload, X, PenLine } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { addToHistory, STYLE_OPTIONS } from "@/lib/history";

const SketchPanel = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [drawing, setDrawing] = useState(false);
  const [brush, setBrush] = useState(4);
  const [erase, setErase] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState("minimal");
  const [count, setCount] = useState(3);
  const [results, setResults] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploaded, setUploaded] = useState<string | null>(null);
  const [tab, setTab] = useState<"draw" | "upload">("draw");

  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, c.width, c.height);
  }, []);

  const getPos = (e: React.MouseEvent | React.TouchEvent) => {
    const c = canvasRef.current!;
    const rect = c.getBoundingClientRect();
    const clientX = "touches" in e ? e.touches[0].clientX : e.clientX;
    const clientY = "touches" in e ? e.touches[0].clientY : e.clientY;
    return {
      x: ((clientX - rect.left) / rect.width) * c.width,
      y: ((clientY - rect.top) / rect.height) * c.height,
    };
  };

  const start = (e: React.MouseEvent | React.TouchEvent) => {
    setDrawing(true);
    const ctx = canvasRef.current!.getContext("2d")!;
    const { x, y } = getPos(e);
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const move = (e: React.MouseEvent | React.TouchEvent) => {
    if (!drawing) return;
    const ctx = canvasRef.current!.getContext("2d")!;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.lineWidth = erase ? brush * 4 : brush;
    ctx.strokeStyle = erase ? "#ffffff" : "#0a0a0a";
    const { x, y } = getPos(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const end = () => setDrawing(false);

  const clear = () => {
    const c = canvasRef.current!;
    const ctx = c.getContext("2d")!;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, c.width, c.height);
  };

  const onFile = (f: File | undefined) => {
    if (!f) return;
    const reader = new FileReader();
    reader.onload = (e) => setUploaded(e.target?.result as string);
    reader.readAsDataURL(f);
  };

  const enhance = async () => {
    let dataUrl: string;
    if (tab === "upload") {
      if (!uploaded) {
        toast.error("Upload a hand-drawn image first.");
        return;
      }
      dataUrl = uploaded;
    } else {
      dataUrl = canvasRef.current!.toDataURL("image/png");
    }
    setLoading(true);
    setResults([]);
    try {
      const { data, error } = await supabase.functions.invoke("generate-image", {
        body: { prompt, referenceImage: dataUrl, mode: "sketch", style, count },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      const imgs: string[] = data.images || (data.image ? [data.image] : []);
      setResults(imgs);
      addToHistory(imgs.map((image) => ({ mode: "sketch" as const, prompt, style, image })));
      toast.success(`Generated ${imgs.length} logo${imgs.length > 1 ? "s" : ""}!`);
    } catch (e: any) {
      toast.error(e.message || "Enhancement failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card className="bg-gradient-surface border-border p-6 shadow-card">
        <h2 className="text-xl font-semibold">Sketch to Logo</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Draw it or upload your hand-drawn picture — AI turns it into polished logos.
        </p>

        <div className="mt-4 inline-flex rounded-lg border border-border bg-background/40 p-1">
          <button
            onClick={() => setTab("draw")}
            className={`flex items-center gap-2 rounded-md px-3 py-1.5 text-sm ${tab === "draw" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
          >
            <PenLine className="h-4 w-4" /> Draw
          </button>
          <button
            onClick={() => setTab("upload")}
            className={`flex items-center gap-2 rounded-md px-3 py-1.5 text-sm ${tab === "upload" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
          >
            <Upload className="h-4 w-4" /> Upload
          </button>
        </div>

        {tab === "draw" ? (
          <>
            <div className="mt-4 overflow-hidden rounded-xl border border-border bg-white">
              <canvas
                ref={canvasRef}
                width={800}
                height={600}
                className="h-auto w-full cursor-crosshair touch-none"
                onMouseDown={start}
                onMouseMove={move}
                onMouseUp={end}
                onMouseLeave={end}
                onTouchStart={start}
                onTouchMove={move}
                onTouchEnd={end}
              />
            </div>
            <div className="mt-4 flex items-center gap-3">
              <div className="flex-1">
                <label className="mb-1 block text-xs text-muted-foreground">Brush size: {brush}px</label>
                <Slider value={[brush]} onValueChange={(v) => setBrush(v[0])} min={1} max={20} step={1} />
              </div>
              <Button variant={erase ? "default" : "outline"} size="sm" onClick={() => setErase(!erase)}>
                <Eraser className="mr-2 h-4 w-4" /> Eraser
              </Button>
              <Button variant="outline" size="sm" onClick={clear}>
                <Trash2 className="mr-2 h-4 w-4" /> Clear
              </Button>
            </div>
          </>
        ) : (
          <div className="mt-4">
            {uploaded ? (
              <div className="relative overflow-hidden rounded-xl border border-border bg-white">
                <img src={uploaded} alt="Hand-drawn upload" className="max-h-[400px] w-full object-contain" />
                <button
                  onClick={() => setUploaded(null)}
                  className="absolute right-2 top-2 rounded-full bg-destructive p-1.5 text-destructive-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => fileRef.current?.click()}
                className="flex h-64 w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-border bg-background/30 text-muted-foreground transition-smooth hover:border-primary/50 hover:text-foreground"
              >
                <Upload className="h-8 w-8" />
                <p className="text-sm font-medium">Upload your hand-drawn picture</p>
                <p className="text-xs">PNG, JPG — AI will analyze and recreate as a logo</p>
              </button>
            )}
            <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => onFile(e.target.files?.[0])} />
          </div>
        )}

        <div className="mt-4 grid grid-cols-2 gap-3">
          <div>
            <label className="mb-2 block text-sm font-medium">Style</label>
            <Select value={style} onValueChange={setStyle}>
              <SelectTrigger className="bg-background/50"><SelectValue /></SelectTrigger>
              <SelectContent>
                {STYLE_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">Variations</label>
            <Select value={String(count)} onValueChange={(v) => setCount(Number(v))}>
              <SelectTrigger className="bg-background/50"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="2">2 logos</SelectItem>
                <SelectItem value="3">3 logos</SelectItem>
                <SelectItem value="4">4 logos</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Optional: describe the brand or details you want..."
          className="mt-4 min-h-20 resize-none bg-background/50"
        />

        <Button
          onClick={enhance}
          disabled={loading}
          className="mt-4 w-full bg-gradient-hero text-primary-foreground hover:opacity-90 glow-primary"
        >
          {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Enhancing...</> : <><Wand2 className="mr-2 h-4 w-4" /> Generate {count} logos</>}
        </Button>
      </Card>

      <Card className="bg-gradient-surface border-border p-6 shadow-card">
        <h2 className="text-xl font-semibold">Enhanced Logos</h2>
        <p className="mt-1 text-sm text-muted-foreground">Pick your favorite and download.</p>
        <div className="mt-5 grid grid-cols-2 gap-4">
          {loading && Array.from({ length: count }).map((_, i) => (
            <div key={i} className="flex aspect-square items-center justify-center rounded-xl border border-border bg-background/40">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ))}
          {!loading && results.length === 0 && (
            <div className="col-span-2 flex aspect-square items-center justify-center rounded-xl border border-border bg-background/40">
              <p className="text-sm text-muted-foreground">Your enhanced logos will appear here.</p>
            </div>
          )}
          {!loading && results.map((src, i) => (
            <div key={i} className="group relative overflow-hidden rounded-xl border border-border bg-background/40">
              <img src={src} alt={`Logo ${i + 1}`} className="aspect-square w-full object-contain" />
              <a
                href={src}
                download={`graloo-sketch-${i + 1}.png`}
                className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-2 bg-background/80 py-2 text-sm font-medium opacity-0 backdrop-blur transition-opacity group-hover:opacity-100"
              >
                <Download className="h-4 w-4" /> Download
              </a>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default SketchPanel;
