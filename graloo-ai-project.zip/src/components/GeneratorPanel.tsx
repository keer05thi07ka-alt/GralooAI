import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Upload, Wand2, X, Download, Loader2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { addToHistory, STYLE_OPTIONS } from "@/lib/history";

interface GeneratorPanelProps {
  mode: "logo" | "graphic";
  title: string;
  description: string;
  placeholder: string;
}

const GeneratorPanel = ({ mode, title, description, placeholder }: GeneratorPanelProps) => {
  const [prompt, setPrompt] = useState("");
  const [reference, setReference] = useState<string | null>(null);
  const [style, setStyle] = useState<string>("minimal");
  const [count, setCount] = useState<number>(3);
  const [results, setResults] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const onFile = (f: File | undefined) => {
    if (!f) return;
    const reader = new FileReader();
    reader.onload = (e) => setReference(e.target?.result as string);
    reader.readAsDataURL(f);
  };

  const generate = async () => {
    if (!prompt.trim() && !reference) {
      toast.error("Add a prompt or reference image to start.");
      return;
    }
    setLoading(true);
    setResults([]);
    try {
      const { data, error } = await supabase.functions.invoke("generate-image", {
        body: { prompt, referenceImage: reference, mode, style, count },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      const imgs: string[] = data.images || (data.image ? [data.image] : []);
      setResults(imgs);
      addToHistory(imgs.map((image) => ({ mode, prompt, style, image })));
      toast.success(`Generated ${imgs.length} variation${imgs.length > 1 ? "s" : ""}!`);
    } catch (e: any) {
      toast.error(e.message || "Generation failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card className="bg-gradient-surface border-border p-6 shadow-card">
        <h2 className="text-xl font-semibold">{title}</h2>
        <p className="mt-1 text-sm text-muted-foreground">{description}</p>

        <div className="mt-5 space-y-4">
          <div>
            <label className="mb-2 block text-sm font-medium">Prompt</label>
            <Textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={placeholder}
              className="min-h-32 resize-none bg-background/50"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-2 block text-sm font-medium">Style</label>
              <Select value={style} onValueChange={setStyle}>
                <SelectTrigger className="bg-background/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STYLE_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="mb-2 block text-sm font-medium">Variations</label>
              <Select value={String(count)} onValueChange={(v) => setCount(Number(v))}>
                <SelectTrigger className="bg-background/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2">2 variations</SelectItem>
                  <SelectItem value="3">3 variations</SelectItem>
                  <SelectItem value="4">4 variations</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium">Reference image (optional)</label>
            {reference ? (
              <div className="relative inline-block">
                <img src={reference} alt="reference" className="h-32 w-32 rounded-lg border border-border object-cover" />
                <button
                  onClick={() => setReference(null)}
                  className="absolute -right-2 -top-2 rounded-full bg-destructive p-1 text-destructive-foreground"
                  aria-label="Remove reference"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => fileRef.current?.click()}
                className="flex h-32 w-full items-center justify-center rounded-lg border border-dashed border-border bg-background/30 text-sm text-muted-foreground transition-smooth hover:border-primary/50 hover:text-foreground"
              >
                <Upload className="mr-2 h-4 w-4" /> Upload reference photo
              </button>
            )}
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              hidden
              onChange={(e) => onFile(e.target.files?.[0])}
            />
          </div>

          <Button
            onClick={generate}
            disabled={loading}
            className="w-full bg-gradient-hero text-primary-foreground hover:opacity-90 glow-primary"
          >
            {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Generating {count} variations...</> : <><Wand2 className="mr-2 h-4 w-4" /> Generate {count} variations</>}
          </Button>
        </div>
      </Card>

      <Card className="bg-gradient-surface border-border p-6 shadow-card">
        <h2 className="text-xl font-semibold">Results</h2>
        <p className="mt-1 text-sm text-muted-foreground">Pick your favorite and download.</p>

        <div className="mt-5 grid grid-cols-2 gap-4">
          {loading && Array.from({ length: count }).map((_, i) => (
            <div key={i} className="flex aspect-square items-center justify-center rounded-xl border border-border bg-background/40">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ))}
          {!loading && results.length === 0 && (
            <div className="col-span-2 flex aspect-square items-center justify-center rounded-xl border border-border bg-background/40">
              <p className="text-sm text-muted-foreground">Your generated {mode}s will appear here.</p>
            </div>
          )}
          {!loading && results.map((src, i) => (
            <div key={i} className="group relative overflow-hidden rounded-xl border border-border bg-background/40">
              <img src={src} alt={`Variation ${i + 1}`} className="aspect-square w-full object-contain" />
              <a
                href={src}
                download={`graloo-${mode}-${i + 1}.png`}
                className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-2 bg-background/80 py-2 text-sm font-medium opacity-0 backdrop-blur transition-opacity group-hover:opacity-100"
              >
                <Download className="h-4 w-4" /> Download
              </a>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default GeneratorPanel;
