import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Download, Trash2, History as HistoryIcon } from "lucide-react";
import { getHistory, removeFromHistory, clearHistory, type HistoryItem } from "@/lib/history";

const HistoryPanel = () => {
  const [items, setItems] = useState<HistoryItem[]>([]);

  useEffect(() => {
    const refresh = () => setItems(getHistory());
    refresh();
    window.addEventListener("graloo-history-updated", refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener("graloo-history-updated", refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  if (items.length === 0) {
    return (
      <Card className="bg-gradient-surface border-border p-12 shadow-card">
        <div className="flex flex-col items-center text-center">
          <div className="rounded-full bg-primary/10 p-4">
            <HistoryIcon className="h-8 w-8 text-primary" />
          </div>
          <h3 className="mt-4 text-lg font-semibold">Your collection is empty</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            Generated logos and graphics will be saved here automatically.
          </p>
        </div>
      </Card>
    );
  }

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{items.length} saved item{items.length > 1 ? "s" : ""}</p>
        <Button variant="outline" size="sm" onClick={clearHistory}>
          <Trash2 className="mr-2 h-4 w-4" /> Clear all
        </Button>
      </div>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {items.map((it) => (
          <Card key={it.id} className="group overflow-hidden border-border bg-gradient-surface p-0 shadow-card">
            <div className="relative aspect-square bg-background/40">
              <img src={it.image} alt={it.prompt} className="h-full w-full object-contain" />
              <div className="absolute inset-x-0 bottom-0 flex translate-y-full items-center justify-center gap-2 bg-background/80 py-2 backdrop-blur transition-transform group-hover:translate-y-0">
                <a href={it.image} download={`graloo-${it.mode}.png`}>
                  <Button size="sm" variant="outline"><Download className="mr-1 h-3 w-3" /> Save</Button>
                </a>
                <Button size="sm" variant="outline" onClick={() => removeFromHistory(it.id)}>
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <div className="p-3">
              <div className="flex items-center gap-2">
                <span className="rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-primary">{it.mode}</span>
                {it.style && <span className="text-[10px] text-muted-foreground">{it.style}</span>}
              </div>
              <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{it.prompt || "No prompt"}</p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default HistoryPanel;
