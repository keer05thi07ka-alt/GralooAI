import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sparkles, PenTool, ImageIcon, Home, History } from "lucide-react";
import { Button } from "@/components/ui/button";
import GeneratorPanel from "./GeneratorPanel";
import SketchPanel from "./SketchPanel";
import HistoryPanel from "./HistoryPanel";

interface DashboardProps {
  onHome: () => void;
}

const Dashboard = ({ onHome }: DashboardProps) => {
  const [tab, setTab] = useState("logo");

  return (
    <main className="relative min-h-screen">
      <div className="absolute inset-0 grid-bg opacity-30 pointer-events-none" />
      <header className="relative z-10 mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
        <button onClick={onHome} className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-hero glow-primary">
            <Sparkles className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-lg font-semibold tracking-tight">GralooAI</span>
        </button>
        <Button variant="ghost" size="sm" onClick={onHome}>
          <Home className="mr-2 h-4 w-4" /> Home
        </Button>
      </header>

      <section className="relative z-10 mx-auto max-w-7xl px-6 pb-20">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Studio</h1>
          <p className="mt-1 text-muted-foreground">Choose a workspace and bring your ideas to life.</p>
        </div>

        <Tabs value={tab} onValueChange={setTab} className="w-full">
          <TabsList className="grid w-full max-w-3xl grid-cols-4 bg-card/60 backdrop-blur">
            <TabsTrigger value="logo" className="gap-2"><Sparkles className="h-4 w-4" />Logo</TabsTrigger>
            <TabsTrigger value="graphic" className="gap-2"><ImageIcon className="h-4 w-4" />Graphics</TabsTrigger>
            <TabsTrigger value="sketch" className="gap-2"><PenTool className="h-4 w-4" />Sketch</TabsTrigger>
            <TabsTrigger value="history" className="gap-2"><History className="h-4 w-4" />History</TabsTrigger>
          </TabsList>

          <TabsContent value="logo" className="mt-6">
            <GeneratorPanel
              mode="logo"
              title="Logo Generator"
              description="Describe your brand. Optionally upload a reference image to guide the style."
              placeholder="A minimal mountain logo for an outdoor coffee brand, earthy tones..."
            />
          </TabsContent>

          <TabsContent value="graphic" className="mt-6">
            <GeneratorPanel
              mode="graphic"
              title="Graphics Generator"
              description="Generate banners, illustrations, or social posts from a prompt and reference."
              placeholder="A vibrant abstract banner with flowing waves of teal and magenta..."
            />
          </TabsContent>

          <TabsContent value="sketch" className="mt-6">
            <SketchPanel />
          </TabsContent>

          <TabsContent value="history" className="mt-6">
            <HistoryPanel />
          </TabsContent>
        </Tabs>
      </section>
    </main>
  );
};

export default Dashboard;
